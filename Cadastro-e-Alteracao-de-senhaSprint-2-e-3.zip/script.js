const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const btnPopup = document.querySelector('.btnLogin-popup');
const iconClose = document.querySelector('.icon-close');
const esqueceuLink= document.querySelector('.esqueceu-link');

registerLink.addEventListener('click', () => {
  wrapper.classList.add('active');
});

loginLink.addEventListener('click', () => {
  wrapper.classList.remove('active');
});

esqueceuLink.addEventListener('click', () => {
  wrapper.classList.add('active');
  document.querySelector('.form-box.login').style.display = 'none';
  document.querySelector('.form-box.alterar').style.display = 'block';
});

btnPopup.addEventListener('click', () => {
  wrapper.classList.add('active-popup');
});

iconClose.addEventListener('click', () => {
  wrapper.classList.remove('active-popup');
});

document.addEventListener('click', (event) => {
  const target = event.target;
  if (!target.closest('.wrapper') && !target.closest('.btnLogin-popup')) {
    wrapper.classList.remove('active');
    wrapper.classList.remove('active-popup');
    document.querySelector('.form-box.login').style.display = 'block';
    document.querySelector('.form-box.alterar').style.display = 'none';
  }
});


//Cadastro
function leDados() {
  let strDados = localStorage.getItem('db');
  let objDados = {};

  if (strDados) {
    objDados = JSON.parse(strDados);
  } else {
    objDados = {
      cadastros: [
        {
          id: 1,
          nome_user: "Sarah Fortune",
          email: "sarahfortune@gmail.com",
          senha: "837292383"
        },
        {
          id: 2,
          nome_user: "Isaac Clark",
          email: "isaacclark@gmail.com",
          senha: "6473262484"
        },
        {
          id: 3,
          nome_user: "Nathan Drake",
          email: "nathandrake@gmail.com",
          senha: "4564244334"
        }
      ]
    };
  }

  return objDados;
}

function salvaDados(dados) {
  localStorage.setItem('db', JSON.stringify(dados));
}

function incluirContato() {
  let objDados = leDados();

  let strId = document.getElementById('id').value;
  let strUser = document.getElementById('nome_user').value;
  let strEmail = document.getElementById('email').value;
  let strSenha = document.getElementById('senha').value;

  let novoCadastro = {
    id: strId,
    nome_user: strUser,
    email: strEmail,
    senha: strSenha
  };

  objDados.cadastros.push(novoCadastro);

  salvaDados(objDados);

  imprimeDados();
}

function imprimeDados() {
  let tela = document.getElementById('tela');
  let strHtml = '';
  let objDados = leDados();

  for (let i = 0; i < objDados.cadastros.length; i++) {
    strHtml += `<p>${objDados.cadastros[i].id} 
    ${objDados.cadastros[i].nome_user} 
    ${objDados.cadastros[i].email} 
    ${objDados.cadastros[i].senha}</p>`;
  }

  tela.innerHTML = strHtml;
}


document.getElementById('btnCarregaDados').addEventListener('click', imprimeDados);
document.getElementById('submit').addEventListener('click', incluirContato);

//Alterar senha, analisar código abaixo para sprint 3 
function alterarSenha() {
  let objDados = leDados();

  let strNovaSenha = document.getElementById('novaSenha').value;
  let strConfirmacaoSenha = document.getElementById('confirmarSenha').value;

  if (strNovaSenha === strConfirmacaoSenha) {
    let strId = prompt('Digite o ID do usuário que deseja alterar a senha:');
    let cadastro = objDados.cadastros.find(c => c.id === strId);

    if (cadastro) {
      cadastro.senha = strNovaSenha;
      salvaDados(objDados);
      alert('Senha alterada com sucesso!');
      document.getElementById('novaSenha').value = '';
      document.getElementById('confirmarSenha').value = '';
      document.querySelector('.form-box.login').style.display = 'block';
      document.querySelector('.form-box.alterar').style.display = 'none';
    } else {
      alert('ID de usuário inválido!');
    }
  } else {
    alert('As senhas não coincidem!');
  }
}