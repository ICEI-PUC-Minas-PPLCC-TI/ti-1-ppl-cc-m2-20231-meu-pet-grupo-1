const form = document.getElementById('form');
const usuario = document.getElementById('username');
const email = document.getElementById('email');
const senha = document.getElementById('password');
const senhaConf = document.getElementById('password-confirmation');
const despesas = document.getElementById('despesa');
const renda = document.getElementById('renda');
const nomec = document.getElementById('nomec');
form.addEventListener('submit', (e) => {
    e.preventDefault();/*não recarregar a página ao enviar formulário */

    checkInputs();//chamar função
});


//validar erros
function checkInputs() 
{
    const usuarioValue = usuario.value;
    const nomecValue = nomec.value;
    const emailValue = email.value;
    const senhaValue = senha.value;
    const senhaConfValue = senhaConf.value;
    const rendaValue = renda.value;
    const despesaValue = despesas.value;

    // verificar se usuário já foi cadastrado
 let users = JSON.parse(localStorage.getItem("users")) || [];
 const userExists = users.find(user => user.username === usuarioValue);
 const emailExists = users.find(user => user.email === emailValue);


    //todos os campos obrigatóyios
    
    if(nomecValue=='')//se campo vazio
    {
        //chamar função de erro
        erro(nomec, "O nome é obrigatório");  
    }
    else{
        sucesso(nomec);
    }
    if(usuarioValue=='')//se campo vazio
    {
        //chamar função de erro
        erro(usuario, "O nome de usuário é obrigatório.");  
    }
    else if (userExists) {
        erro(usuario, "Este nome de usuário já está em uso.");
        return;
     }

    
    else{
        sucesso(usuario);//chamar função de sucesso
    }

    //email
    if(emailValue=='')
    {
        erro(email,"O email é obrigatório.");
    }

    //se checarEmail retornar falso=email inválido
    else if(!checarEmail(emailValue)){
        erro(email,"Insira um email válido")

    }
    else if (emailExists) {
        erro(email, "Este email já está cadastrado.");
        return;
     }
    
    else{
        sucesso(email);
    }

    //senha
    if(senhaValue=='')
    {
        erro(senha,"A senha é obrigatória");
    }
    //se senha iver menos de 8 caracteres=erro
    else if(senhaValue.length < 8){
        erro(senha,"A senha precisa ter no mínimo 8 caracteres");
    }
    else{
        sucesso(senha);
    }

    //confirmação de senha
    if(senhaConfValue=='')
    {
        erro(senhaConf,"Confirme a senha")
    }
    else if(senhaConfValue!=senhaValue)
    {
        erro(senhaConf,"As senhas não são iguais");
    }
    else{
        sucesso(senhaConf);
    }

    if(despesaValue=='')
    {
        erro(despesas, "Insira um valor");
    }
    else{
        sucesso(despesas);
    }

    if(rendaValue=='')
    {
        erro(renda, "Insira um valor");
    }
    else{
        sucesso(renda);
    }



    const formControls = form.querySelectorAll(".form-control");

    const formIsValid = [...formControls].every((formControl) => {
      return formControl.className === "form-control success";
    });
  
    if (formIsValid) {
      console.log("Usuário cadastrado");
      var mensagemSucesso = document.getElementById("mensagem-sucesso");
  mensagemSucesso.innerHTML = "Usuário cadastrado com sucesso!";
  window.location.href = "https://pagina-inicial-teste--ceciliafsc.repl.co";

  // Criar objeto com as informações do usuário
  const user = {
  nome: nomecValue,
  username: usuarioValue,
  email: emailValue,
  password: senhaValue,
  renda: rendaValue,
  despesa: despesaValue
};

// Converter para uma string JSON
const userJSON = JSON.stringify(user);

// Salvar informações do usuário no local storage
localStorage.setItem('user', userJSON);
    }
}

//Função erro
function erro(input,message)
{
    const formControl=input.parentElement;//retorna classe da div pai do elemento
    const small= formControl.querySelector("small");

    //adicionar mensagem de erro
    small.innerText=message;

    //adicionar classe de erro
    formControl.className = "form-control error";

}

//função sucesso
function sucesso(input)
{
    const formControl= input.parentElement;//classe da div

    //adicionar classe de sucesso
    formControl.className = "form-control success";
}


//função para checar email inválido
function checarEmail(email) {
    return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
      email
    );}//retorna true se email for válido