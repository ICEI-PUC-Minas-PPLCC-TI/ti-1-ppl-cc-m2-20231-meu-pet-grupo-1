function validarCadastro() {
const form = document.getElementById('form');
const economia = document.getElementById('economia');
const despesas = document.getElementById('despesa');
const renda = document.getElementById('renda');
const possuiDividaSim = document.getElementById('possui-divida-sim');
const possuiDividaNao = document.getElementById('possui-divida-nao');
const valorDividaContainer = document.getElementById('valor-divida-container');
const valorDivida = document.getElementById('valor-divida');

form.addEventListener('submit', (e) => {
    e.preventDefault();
    checkInputs();
});

possuiDividaSim.addEventListener('change', () => {
    if (possuiDividaSim.checked) {
        possuiDividaNao.checked = false;
        valorDividaContainer.style.display = 'block';
    } else {
        valorDividaContainer.style.display = 'none';
    }
});

possuiDividaNao.addEventListener('change', () => {
    if (possuiDividaNao.checked) {
        possuiDividaSim.checked = false;
        valorDividaContainer.style.display = 'none';
    }
});

function checkInputs() {
    const economiaValue = economia.value;
    const rendaValue = renda.value;
    const despesaValue = despesas.value;
    const possuiDividaValue = possuiDividaSim.checked;
    const valorDividaValue = valorDivida.value;

    if (economiaValue == '') {
        erro(economia, "Insira um valor.");
    } else {
        sucesso(economia);
    }

    if (despesaValue == '') {
        erro(despesas, "Insira um valor");
    } else {
        sucesso(despesas);
    }

    if (rendaValue == '') {
        erro(renda, "Insira um valor");
    } else {
        sucesso(renda);
    }

    if (possuiDividaValue) {
        if (valorDividaValue == '') {
            erro(valorDivida, "Insira um valor para a dívida");
        } else {
            sucesso(valorDivida);
        }
    }

    const formControls = form.querySelectorAll(".form-control");

    const formIsValid = [...formControls].every((formControl) => {
        return formControl.className === "form-control success";
    });

    if (formIsValid) {
        window.location.href = "https://pagina-inicial-teste--ceciliafsc.repl.co";
        
        const user = {
            renda: rendaValue,
            despesa: despesaValue,
            possuiDivida: possuiDividaValue,
            valorDivida: valorDividaValue
        };

        const userJSON = JSON.stringify(user);

        localStorage.setItem('user', userJSON);
    }
}

function erro(input, message) {
    const formControl = input.parentElement;
    const small = formControl.querySelector("small");

    small.innerText = message;

    formControl.className = "form-control error";
}

function sucesso(input) {
    const formControl = input.parentElement;

    formControl.className = "form-control success";
}

window.addEventListener('load', () => {
    if (!possuiDividaSim.checked) {
        valorDividaContainer.style.display = 'none';
    }
});}
